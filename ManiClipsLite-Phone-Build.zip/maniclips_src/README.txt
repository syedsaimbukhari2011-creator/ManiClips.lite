MANICLIPS LITE — ANDROID PROJECT
================================

This is the Android Studio source project for ManiClips Lite. It is NOT an APK.

CURRENT FEATURES
- Choose a video from the Android system file picker.
- Select a clip duration of 30, 45, or 60 seconds.
- Export the beginning of the video as an MP4.
- Export files are stored in the app-specific Movies folder.

REQUIREMENTS
- Android Studio (current stable release).
- JDK 17 (Android Studio can use its bundled JDK).
- Android SDK Platform 35.
- Internet connection for the first Gradle sync, to download Android and Media3 dependencies.

BUILD AN APK (WINDOWS / MAC / LINUX)
1. Extract this ZIP to a normal folder (do not try to build it from inside the ZIP).
2. Open Android Studio.
3. Choose File > Open, then select the extracted ManiClipsLite folder
   (the folder containing settings.gradle.kts).
4. Wait for Gradle Sync to finish. If prompted, install Android SDK Platform 35.
5. Choose Build > Build Bundle(s) / APK(s) > Build APK(s).
6. When the build finishes, choose “locate” in the notification. The debug APK is at:
   app/build/outputs/apk/debug/app-debug.apk

INSTALL ON AN ANDROID PHONE
1. Transfer app-debug.apk to the phone.
2. Open the APK on the phone and approve installation from that file app if Android asks.
3. Launch “ManiClips Lite”.

NOTES
- Minimum Android version: Android 6.0 (API 23).
- The first build needs internet access to download Gradle plugins and dependencies.
- This environment does not include the Android SDK / Gradle build tools, so no compiled APK
  is included and the project has not been device-tested here.
- This starter app exports from the start of the selected video; it does not yet include
  timeline scrubbing, 9:16 crop controls, or AI captions.
