package com.maniclips.lite

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.media3.common.MediaItem
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.Transformer
import java.io.File

class MainActivity : ComponentActivity() {
    private var selectedVideo: Uri? = null
    private var clipSeconds = 30
    private lateinit var status: TextView
    private lateinit var trimButton: Button
    private var transformer: Transformer? = null

    private val picker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            selectedVideo = uri
            try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
            status.text = "Video selected. Clip length: $clipSeconds seconds."
            trimButton.isEnabled = true
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 32, 28, 32)
            setBackgroundColor(0xFF101014.toInt())
        }
        fun text(value: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
            text = value; textSize = size; setTextColor(color)
            if (bold) setTypeface(null, android.graphics.Typeface.BOLD)
            gravity = Gravity.CENTER
            setPadding(0, 12, 0, 12)
        }
        root.addView(text("MANICLIPS LITE", 27f, 0xFFFFFFFF.toInt(), true))
        root.addView(text("Simple video clip maker", 15f, 0xFFBDBDC7.toInt()))
        val choose = Button(this).apply {
            this.text = "CHOOSE VIDEO"
            setOnClickListener { picker.launch(arrayOf("video/*")) }
        }
        root.addView(choose, lp())
        root.addView(text("Choose your clip length", 17f, 0xFFFFFFFF.toInt()))
        val lengths = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        listOf(30, 45, 60).forEach { seconds ->
            val b = Button(this).apply {
                text = "${seconds}s"
                setOnClickListener {
                    clipSeconds = seconds
                    status.text = if (selectedVideo == null) "Select a video to begin." else "Video selected. Clip length: $clipSeconds seconds."
                }
            }
            lengths.addView(b, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { setMargins(4, 4, 4, 4) })
        }
        root.addView(lengths)
        status = text("Select a video to begin.", 14f, 0xFFBDBDC7.toInt())
        root.addView(status)
        trimButton = Button(this).apply {
            text = "CREATE MP4 CLIP"
            isEnabled = false
            setOnClickListener { exportClip() }
        }
        root.addView(trimButton, lp())
        root.addView(text("Exports the first 30, 45 or 60 seconds.\nFiles are saved in ManiClipsLite/Movies.", 12f, 0xFF92929D.toInt()))
        setContentView(root)
    }

    private fun lp() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
        setMargins(0, 10, 0, 10)
    }

    private fun exportClip() {
        val uri = selectedVideo ?: return
        trimButton.isEnabled = false
        status.text = "Preparing MP4 export…"
        val outputDir = getExternalFilesDir("Movies") ?: filesDir
        val output = File(outputDir, "ManiClip_${System.currentTimeMillis()}.mp4")
        val mediaItem = MediaItem.Builder()
            .setUri(uri)
            .setClippingConfiguration(
                MediaItem.ClippingConfiguration.Builder()
                    .setStartPositionMs(0)
                    .setEndPositionMs(clipSeconds * 1000L)
                    .build()
            ).build()
        val edited = EditedMediaItem.Builder(mediaItem).build()
        transformer = Transformer.Builder(this)
            .addListener(object : Transformer.Listener {
                override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                    runOnUiThread {
                        status.text = "Export complete: ${output.name}"
                        trimButton.isEnabled = true
                        Toast.makeText(this@MainActivity, "MP4 saved in ManiClipsLite/Movies", Toast.LENGTH_LONG).show()
                    }
                }
                override fun onError(composition: Composition, exportResult: ExportResult, exportException: ExportException) {
                    runOnUiThread {
                        status.text = "Export failed: ${exportException.message ?: "Unsupported video"}"
                        trimButton.isEnabled = true
                    }
                }
            }).build()
        try {
            transformer?.start(edited, output.absolutePath)
        } catch (e: Exception) {
            status.text = "Could not start export: ${e.message}"
            trimButton.isEnabled = true
        }
    }
}
